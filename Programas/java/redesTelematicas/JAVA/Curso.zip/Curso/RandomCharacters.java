//fig. 13.7  RandomCharacters.java
//demostracion de la interfaz runnable

import java.awt.*;
import java.applet.Applet;
/*
<HTML>
<TITLE>Caracteres_Azar. Applet</TITLE>
<APPLET CODE="RandomCharacters.class"  WIDTH=300 HEIGHT=100>
</APPLET>
</HTML>
*/

public class RandomCharacters extends Applet implements Runnable {

   String alphabet;
   TextField output1, output2, output3;
   Button button1, button2, button3;

   Thread hilo1, hilo2, hilo3;

   boolean suspend1, suspend2, suspend3;

   public void init()
   {
     alphabet = new String( "ABCDEFGHIJKLMNOPQRSTUVWXYZ" );
     output1 = new TextField( 10 );
     output1.setEditable( false );
     output2 = new TextField( 10 );
     output2.setEditable( false );
     output3 = new TextField( 10 );
     output3.setEditable( false );
     button1 = new Button( "Susp./reanudar 1" );
     button2 = new Button( "Susp./reanudar 2" );
     button3 = new Button( "Susp./reanudar 3" );

     add( output1 );
     add( button1 );
     add( output2 );
     add( button2 );
     add( output3 );
     add( button3 );
  }

  public void start()
  {
    //crear hilos y arrancar cada vez que se invoque start
    hilo1 = new Thread( this, "HILO 1" );
    hilo2 = new Thread( this, "HILO 2" );
    hilo3 = new Thread( this, "HILO 3" );

    hilo1.start();
    hilo2.start();
    hilo3.start();

  }
  public void stop()
  {
    //para los hilos cada vez que se invoca stop
    //mientras el usuario curiosea otra pagina de la web
    hilo1.stop();
    hilo2.stop();
    hilo3.stop();
  }

  public boolean action( Event event, Object obj )
  {
     if ( event.target == button1 )
       if ( suspend1 ) {
          hilo1.resume();
          suspend1 = false;
       }
       else {
          hilo1.suspend();
          output1.setText( "Suspendido" );
          suspend1 = true;
      }
   else if ( event.target == button2 )
      if ( suspend2 ) {
         hilo2.resume();
         suspend2 = false;
      }
   else {
         hilo2.suspend();
         output2.setText( "Suspendido" );
         suspend2 = true;
      }
   else if ( event.target == button3 )
         if ( suspend3 ) {
         hilo3.resume();
         suspend3 = false;
     }
     else {
        hilo3.suspend();
        output3.setText( "Suspendido" );
        suspend3 = true;
    }

  return true;
 }

 public void run()
 {
    int location;
    char display;
    String executingThread;

    while ( true ) {
       // dormir entre 0 y 5 segundos
       try {
          Thread.sleep( (int) ( Math.random() * 5000) );
       }
       catch ( InterruptedException e ) {
          e.printStackTrace();
       }

       location = (int) ( Math.random() * 26 );
       display = alphabet.charAt( location );

       executingThread = Thread.currentThread().getName();
                                     
       if ( executingThread.equals("HILO 1" ))
          output1.setText("HILO 1: " + display);
       else if (executingThread.equals("HILO 2"))
          output2.setText("HILO 2: " + display);
       else if (executingThread.equals("HILO 3"))
          output3.setText("HILO 3: " + display);
     }
   }
 }


