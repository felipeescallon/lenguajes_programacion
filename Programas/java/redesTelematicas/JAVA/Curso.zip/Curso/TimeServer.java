package sockets;
import java.lang.System;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.IOException;
import java.util.Date;

public class TimeServer {
  public static void main(String args[]){
    try{
      DatagramSocket socket=new DatagramSocket(2345);
      String dirLocal=InetAddress.getLocalHost().getHostName().trim();
      int puertoLocal=socket.getLocalPort();
      System.out.print(dirLocal+": ");
      System.out.println("Escuchando en Puerto: "+puertoLocal+".");
      int buffer=256;
      byte buffers[]=new byte[buffer];
      DatagramPacket datagrama=new DatagramPacket(buffers,buffer);
      boolean fin=false;
      do{
        socket.receive(datagrama);
        InetAddress dirDestino=datagrama.getAddress();
        String destino=dirDestino.getHostName().trim();
        int puertoDes=datagrama.getPort();
        System.out.println("\nDatagrama Recibido desde "+destino+" en el puerto "+puertoDes+".");
        String datos=new String(datagrama.getData(),0).trim();
        System.out.println("Datos: "+datos);
        if(datos.equalsIgnoreCase("salir"))
          fin=true;
        String tiempo=new Date().toString();
        tiempo.getBytes(0,tiempo.length(),buffers,0);
        datagrama=new DatagramPacket(buffers,buffer,dirDestino,puertoDes);
        socket.send(datagrama);
        System.out.println("Enviado: "+tiempo+" a "+destino+" en el puerto "+puertoDes+".");
      }while(!fin);
    }catch(IOException ex){
      System.out.println("Ocurri� una IOException");
    }
    }
}


