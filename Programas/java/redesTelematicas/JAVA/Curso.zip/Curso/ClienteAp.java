import java.lang.System;
import java.net.Socket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ClienteAp{
	public static void main(String args[]){
		Cliente cliente=new Cliente(args);
		cliente.paramsDestino();
		cliente.paramsLocales();
		cliente.chat();
		cliente.apagar();
	}
}

class Cliente{
        //Datos miembro
        Socket connect;
        DataOutputStream flujoOut;
        DataInputStream flujoIn;

        //M�todos
        public Cliente(String args[]){
                if(args.length!=2)
                        error("Argumentos de entrada err�neos");
                String destino=args[0];
                int puerto=0;
                try{
                        puerto=Integer.valueOf(args[1]).intValue();
                }catch(NumberFormatException ex){
                  error("Puerto no V�lido");
                }
                try{
                        connect=new Socket(destino,puerto);
                }catch(UnknownHostException ex){
                  error("No se puede encontrar Host");
                }
		catch(IOException ex){
                  error("El Servidor no est� corriendo o hubo una IOException");
                }
                try{
                        flujoIn=new DataInputStream(connect.getInputStream());
                        flujoOut=new DataOutputStream(connect.getOutputStream());
                }catch(IOException ex){
                  error("Error creando flujos de entrada y salida");
                }
                System.out.println("conectado a "+destino+" en el puerto "+puerto+".");
        }

        public void paramsDestino(){
                InetAddress destAddress=connect.getInetAddress();
                String nombre=destAddress.getHostName();
                byte ipAddress[]=destAddress.getAddress();
                int puerto=connect.getPort();
                params("Destino ",nombre,ipAddress,puerto);
        }

        public void paramsLocales(){
                InetAddress localAddress=null;
                try{
                        localAddress=InetAddress.getLocalHost();
                }catch(UnknownHostException ex){
                  error("Error estableciendo LocalHost");
                }
                String nombre=localAddress.getHostName();
                byte ipAddress[]=localAddress.getAddress();
                int puerto=connect.getLocalPort();
                params("Host local ",nombre,ipAddress,puerto);
        }

        public void params(String s,String nombre, byte ipAddress[],int puerto){
                System.out.println(s+"es "+nombre+".");
                System.out.print("Direcci�n IP es ");
                for(int i=0;i<ipAddress.length;++i)
                        System.out.print((ipAddress[i]+256)%256+".");
                System.out.println();
                System.out.println("Puerto de "+s+"es"+puerto+".");
        }

        public void chat(){
                DataInputStream entrada=new DataInputStream(System.in);
                boolean fin=false;
                do{
                        try{
                                System.out.print("Enviar, Recibir, o Salir(E/R/S): ");
                                System.out.flush();
                                String line=entrada.readLine();
                                if(line.length()>0){
                                        line=line.toUpperCase();
                                        switch (line.charAt(0)){
                                                case 'E':
                                                        String salLine=entrada.readLine();
                                                        flujoOut.writeBytes(salLine);
                                                        flujoOut.write(13);
                                                        flujoOut.write(10);
                                                        flujoOut.flush();
                                                        break;
                                                case 'R':
                                                        int byteIn;
                                                        System.out.print("***");
                                                        while((byteIn=flujoIn.read())!='\n')
                                                                System.out.write(byteIn);
                                                        System.out.println();
                                                        break;
                                                case 'S':
                                                        fin=true;
                                                        break;
                                                default:
                                                        break;
                                        }
                                }
                        }catch(IOException ex){
                          error("Error leyendo del teclado o del Socket");
                        }
                }while(!fin);
        }

        public void apagar(){
                try{
                        connect.close();
                }catch(IOException ex){
                  error("Error cerrando el Socket");
                }
        }

        public void error(String s){
                System.out.println(s);
                System.exit(1);
        }
}
