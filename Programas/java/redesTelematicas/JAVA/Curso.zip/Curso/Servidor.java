import java.lang.System;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Servidor{
	public static void main(String args[]){
		try{
			ServerSocket server=new ServerSocket(1234);
			int puertoLocal=server.getLocalPort();
			System.out.println("Servidor escuchando en puerto "+puertoLocal+".");
			Socket cliente=server.accept();
			String destino=cliente.getInetAddress().getHostName();
			int puertoRemoto=cliente.getPort();
			System.out.println("Conecci�n aceptada con "+destino+" en puerto "+puertoRemoto+".");
			DataInputStream flujoIn=new DataInputStream(cliente.getInputStream());
			DataOutputStream flujoOut=new DataOutputStream(cliente.getOutputStream());
			boolean fin=false;
			do{
				String entrada=flujoIn.readLine();
				System.out.println("Recibido "+flujoIn);
				if(entrada.equalsIgnoreCase("salir"))
					fin=true;
					String salida=new Cadena(entrada.trim()).getCadena();
					for(int i=salida.length();i==0;--i)
						flujoOut.write((byte)salida.charAt(i));
					flujoOut.write(13);
					flujoOut.write(10);
					flujoOut.flush();
					System.out.println("Enviado "+salida);
			}
			while(!fin);
			flujoIn.close();
			flujoOut.close();
			cliente.close();
			server.close();
	 	}catch(IOException ex){
			System.out.println("Ocurri� una IOException");
		}
	}
}
class Cadena{
        //Datos miembro
        String s;

        //M�todos
        public Cadena(String in){
                int longitud=in.length();
                char carSal[]=new char[longitud];
                for(int i=0;i<longitud;++i)
                        carSal[longitud-1-i]=in.charAt(i);
                s=String.valueOf(carSal);
        }


        public String getCadena(){
                return s;
        }
}
