import java.sql.*;



public class AplicacionBD {

  public static void main(String[] args) {
   
 try{

      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");  //Se carga el driver

      Connection con = DriverManager.getConnection("jdbc:odbc:origenDatos");  //Se hace la conexi�n

      Statement stmt = con.createStatement();  //Se crea el objeto para sentencias SQL
      
      String crearTablaCafes = "create table CAFES "+
                               "(NOMBRE_CAFE varchar(32), ID_PROV integer, PRECIO float, "+
                               "VENTAS integer, TOTAL integer)";  //Sentencia SQL para crear la tabla
      stmt.executeUpdate(crearTablaCafes);  //Se le pasa la sentencia a la Base de Datos

      stmt.executeUpdate("INSERT INTO CAFES " +
                         "VALUES ('Colombiano', 101, 700, 0, 0)");  //Sentencias para introducir datos
      stmt.executeUpdate("INSERT INTO CAFES " +
                         "VALUES ('Frances', 49, 800, 0, 0)");
      stmt.executeUpdate("INSERT INTO CAFES " +
                         "VALUES ('Expres', 150, 900, 0, 0)");
      stmt.executeUpdate("INSERT INTO CAFES " +
                         "VALUES ('Colombiano_Decafeinado', 101, 800, 0, 0)");
      stmt.executeUpdate("INSERT INTO CAFES " +
                         "VALUES ('Frances_Decafeinado', 49, 900, 0, 0)");

      String query = "SELECT NOMBRE_CAFE, PRECIO FROM CAFES";  //Sentencia para recuperar valores de una tabla
      ResultSet rs = stmt.executeQuery(query);  //Se ejecuta la consulta y se obtiene un ResultSet con los datos seleccionados
      while (rs.next()) {
        String s = rs.getString("NOMBRE_CAFE");  //Se leen los datos
        float n = rs.getFloat("PRECIO");
        System.out.println(s + "   " + n);
      }

      String updateString = "UPDATE CAFES " +  //Sentencia de actualizaci�n de datos
                            "SET VENTAS = 75 " +
                            "WHERE NOMBRE_CAFE LIKE 'Colombiano'";
      stmt.executeUpdate(updateString);

      query = "SELECT NOMBRE_CAFE, VENTAS FROM CAFES " +  //Se seleccionan los datos actualizados
                     "WHERE NOMBRE_CAFE LIKE 'Colombiano'";
      rs = stmt.executeQuery(query);
      while (rs.next()) {
                      String s = rs.getString("NOMBRE_CAFE");  //Se muestran los datos actualizados
                      int n = rs.getInt("VENTAS");
                      System.out.println(n + " libras de " + s +
                                                         " vendidas esta semana.");
      }

      updateString = "UPDATE CAFES " +
                            "SET TOTAL = TOTAL + 75 " +
                            "WHERE NOMBRE_CAFE LIKE 'Colombiano'";
      stmt.executeUpdate(updateString);
      query = "SELECT NOMBRE_CAFE, TOTAL FROM CAFES " +
                     "WHERE NOMBRE_CAFE LIKE 'Colombiano'";
      rs = stmt.executeQuery(query);
      while (rs.next()) {
        String s = rs.getString(1);
        int n = rs.getInt(2);
        System.out.println(n + " libras de " + s + " vendidas esta semana.");
      }

    }catch(Exception e){
      System.out.println("Excepci�n en uso de Bases de Datos: "+ e);
    }

  }
}



