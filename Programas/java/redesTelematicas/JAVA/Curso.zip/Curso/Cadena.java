public class Cadena{
	//Datos miembro
	String s;

	//M�todos
	public Cadena(String in){
		int longitud=in.length();
		char carSal[]=new char[longitud];	
		for(int i=0;i<longitud;++i)
			carSal[longitud-1-i]=in.charAt(i);
		s=String.valueOf(carSal);
	}
	

	public String getCadena(){
		return s;
	}
}