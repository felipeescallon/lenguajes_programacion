//Fig. 13.6: SharedCell.java
//Mostrar multiples hilos modificando un objecto compartido.
//usar sincronizacion para asegurar que ambos hilos accedan a la celda compartida correctamenta
import java.awt.*;
import java.applet.Applet;

/*
<applet code="SharedCell1" width=450 height=450>
</applet>
*/

public class SharedCell1 extends Applet { 
   private TextArea output;

   public void init()
   {
      output = new TextArea( 28, 52 );
      add( output );
   }

   public void start()
   {
      HoldInteger h = new HoldInteger( output );
      ProduceInteger p = new ProduceInteger( h );
      ConsumeInteger c = new ConsumeInteger( h );

      p.start();
      c.start();
   }
}

 class ProduceInteger extends Thread{
   private HoldInteger pHold;
   private TextArea output;

   public ProduceInteger( HoldInteger h )
   {
      pHold = h;
   }

   public void run()
   {
      for (int count = 0; count < 10; count++) {
         pHold.setSharedInt( count );
                                    
         //dormir durante un intervalo aleatorio
         try {
            sleep( (int) ( Math.random() * 500 ) );
         }
         catch( InterruptedException e ) {
            System.err.println("Excepci�n" + e.toString() );
         }
      }
   }
}

 class ConsumeInteger extends Thread {
   private HoldInteger cHold;

   public ConsumeInteger( HoldInteger h )
   {
      cHold = h;
   }

   public void run()
   {
      int val;

      val = cHold.getSharedInt();

      while ( val != 9 ) {
         // dormir durante un intervalo aleatorio
         try  {
            sleep( (int) ( Math.random() * 3000 ) );
         }
         catch( InterruptedException e ) {
            System.err.println("Excepcion" + e.toString() );
         }

      val = cHold.getSharedInt();
      }
   }
}

 class HoldInteger {
   private int sharedInt[] = { 9, 9, 9, 9, 9 };
   private boolean writeable = true;
   private boolean readable = false;
   private int readLoc = 0, writeLoc = 0;
   private TextArea output;

   public HoldInteger( TextArea out )
   {
      output = out;
   }
   public synchronized void setSharedInt( int val )
   {
      while ( !writeable ) {
         try {
            output.appendText( " ESPERANDO PARA PRODUCIR " + val );
            wait();
         }
         catch ( InterruptedException e ) {
            System.err.println( " Excepci�n: " + e.toString() );
         }
      }

      sharedInt[ writeLoc ] = val;
      readable = true;

      output.appendText( "\nProduje " + val +
                         " en la celda " + writeLoc );

      writeLoc = ++writeLoc % 5;

      output.appendText( "\twrite " + writeLoc +
                         "\tread " + readLoc );
      printBuffer( output, sharedInt );


      if ( writeLoc == readLoc ) {
         writeable = false;
         output.appendText( "\nBUFFER LLENO" );
      }

      notify();
    }

    public synchronized int getSharedInt()
    {
       int val;

       while ( !readable ) {
          try {
             output.appendText( "ESPERANDO PARA CONSUMIR" );
             wait();
          }
          catch ( InterruptedException e ) {
             System.err.println( "Excepci�n: " + e.toString() );
          }
       }

       writeable = true;
       val = sharedInt[ readLoc ];

       output.appendText( "\nConsumi " + val +
                          " de la celda " + readLoc );

       readLoc = ++readLoc % 5;

       output.appendText( "\twrite " + writeLoc +
                          "\tread " + readLoc );
       printBuffer( output, sharedInt );

       if ( readLoc == writeLoc ) {
          readable = false;
          output.appendText( "\nBUFFER VACIO" );
       }

       notify();
       return val;
    }
  
  public void printBuffer( TextArea out, int buf[] )
  {
     output.appendText( "\tbuffer: " );

     for ( int i = 0; i < buf.length; i++ )
        out.appendText( " " + buf[ i ] );
   }
 }
