//import java.lang.System;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.io.IOException;

public class GetTiempo {
  public static void main(String args[]){
    try{
      DatagramSocket socket=new DatagramSocket();	//
      InetAddress dirLocal=InetAddress.getLocalHost();
      String localHost=dirLocal.getHostName();
      int buffer=256;
      byte buffers[];
      DatagramPacket datagrama;
      for(int i=0;i<5;++i){		//tama�o del paquete
        buffers=new byte[buffer];
        "Tiempo".getBytes(0,4,buffers,0);
        datagrama=new DatagramPacket(buffers,256,dirLocal,2345);
        socket.send(datagrama);
        System.out.println("\nEnviando respuesta a "+localHost+" en puerto 2345");
        socket.receive(datagrama);
        InetAddress dirDes=datagrama.getAddress();
        String destHost=dirDes.getHostName().trim();
        int desPuerto=datagrama.getPort();
        System.out.println("Recibido datagrama desde "+destHost+" en el puerto "+desPuerto+".");
        String datos=new String(datagrama.getData(),0).trim();
        System.out.println("Datos: "+datos);
      }
      buffers=new byte[buffer];
      "salir".getBytes(0,4,buffers,0);
      datagrama=new DatagramPacket(buffers,256,dirLocal,2345);
      socket.send(datagrama);
    }catch(IOException ex){
            System.out.println("Ocurri� una IOException");
    }
  }
}
