import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;

public class Servidor{
	public static void main(String args[]){
		try{
			ServerSocket server=new ServerSocket(1234); 	//creamos un socket servidor
			int puertoLocal=server.getLocalPort();		//conocer las caracteristicas de la conexion.
									//En que puerto voy a escuchar. En este caso 1234
			System.out.println("Servidor escuchando en puerto "+puertoLocal+".");
			Socket cliente=server.accept();			//creamos un socket cliente.
									//El servidor Se queda esperando una conexion
			String destino=cliente.getInetAddress().getHostName();	//pido la informacion del cliente, y el DN
			int puertoRemoto=cliente.getPort();		//pido el puerto en el que el cliente se conecta
			System.out.println("Conecci�n aceptada con "+destino+" en puerto "+puertoRemoto+".");
			DataInputStream flujoIn=new DataInputStream(cliente.getInputStream());	   //creamos el flujo por el
												   //que se va a enviar la
			DataOutputStream flujoOut=new DataOutputStream(cliente.getOutputStream()); //informacion
			
			boolean fin=false;
			do{
				String entrada=flujoIn.readUTF();	//llega flujo de entrada. Debo leerlo pero necesito
									//el mismo formato que se haya utilizado en el cliente
				if(entrada.equalsIgnoreCase("salir"))	//verifica si el cliente se sale
					fin=true;
				System.out.println("Recibido "+entrada);
			}
			while(!fin);
//Si no se cierran los flujos, se liberan cuando el objeto se ha destruido
			flujoIn.close();	
			flujoOut.close();
			cliente.close();
			server.close();
	 	}catch(IOException ex){
			System.out.println("Ocurri� una IOException");
		}
	}
}