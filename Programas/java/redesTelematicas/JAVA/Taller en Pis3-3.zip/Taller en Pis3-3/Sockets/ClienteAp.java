
import java.net.Socket;
import java.net.InetAddress;  		//encapsula la informacion de la conexion DNS
import java.net.UnknownHostException;	//para manejo de errores
import java.io.DataInputStream;		//para los flujos que voy a utilizar
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;

public class ClienteAp{		
	public static void main(String args[]){		
		Cliente cliente=new Cliente(args);	//creamos un socket cliente
		cliente.paramsDestino();		//caracteristicas de tipo de destino
		cliente.paramsLocales();
		cliente.chat();
		cliente.apagar();			//cerrar los sockets
	}
}

class Cliente{
        //Datos miembro
        Socket connect;			//socket de cliente
        DataOutputStream flujoOut;
        DataInputStream flujoIn;

        //M�todos
        public Cliente(String args[]){		//al constructor le paso un arrglo de cadenas
                if(args.length!=2)		//el primer parametro es el DN y el segundo el puerto
                        error("Argumentos de entrada err�neos");
                String destino=args[0];		//almaceno los parametros
                int puerto=0;
                
		try{		//necesario para evitar errores
                        puerto=Integer.valueOf(args[1]).intValue();	//hacemos la conversion de cadena a entero
                }catch(NumberFormatException ex){
                  error("Puerto no V�lido");
                }
                try{
                        connect=new Socket(destino,puerto);	//instanciamos el objeto con destino y puerto
                }catch(UnknownHostException ex){
                  error("No se puede encontrar Host");
                }
		catch(IOException ex){
                  error("El Servidor no est� corriendo o hubo una IOException");
                }
                try{						//establecemos flujos de salida y entrada
                        flujoIn=new DataInputStream(connect.getInputStream());
                        flujoOut=new DataOutputStream(connect.getOutputStream());
                }catch(IOException ex){
                  error("Error creando flujos de entrada y salida");
                }
                System.out.println("conectado a "+destino+" en el puerto "+puerto+".");
        }

        public void paramsDestino(){	
                InetAddress destAddress=connect.getInetAddress();	//obtenemos las caracteristicas del equipo remoto
                String nombre=destAddress.getHostName();
                byte ipAddress[]=destAddress.getAddress();
                int puerto=connect.getPort();
                params("Destino ",nombre,ipAddress,puerto);
        }

        public void paramsLocales(){
                InetAddress localAddress=null;		//para el equipo local
                try{
                        localAddress=InetAddress.getLocalHost();
                }catch(UnknownHostException ex){
                  error("Error estableciendo LocalHost");
                }
                String nombre=localAddress.getHostName();
                byte ipAddress[]=localAddress.getAddress();
                int puerto=connect.getLocalPort();
                params("Host local ",nombre,ipAddress,puerto);
        }

        public void params(String s,String nombre, byte ipAddress[],int puerto){	
                System.out.println(s+"es "+nombre+".");
                System.out.print("Direcci�n IP es ");
                for(int i=0;i<ipAddress.length;++i)		//convertimos la dir IP en bytes a cadena
                        System.out.print((ipAddress[i]+256)%256+".");
                System.out.println();
                System.out.println("Puerto de "+s+"es"+puerto+".");
        }

        public void chat(){
                //DataInputStream entrada=new DataInputStream(System.in);

               BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
		//String s = teclado.readLine();  Lanza IOException 

                boolean fin=false;
                do{
                        try{
                                System.out.print("Enviar, Recibir, o Salir(E/R/S): ");
                                System.out.flush();
                                String line=entrada.readLine();
                                if(line.length()>0){
                                        line=line.toUpperCase();
                                        switch (line.charAt(0)){
                                                case 'E':
                                                        String salLine=entrada.readLine();
                                                        flujoOut.writeUTF(salLine);
                                                        break;
                                                case 'R':
                                                        int byteIn;
                                                        System.out.print("***");
                                                        while((byteIn=flujoIn.read())!='\n')
                                                                System.out.write(byteIn);
                                                        System.out.println();
                                                        break;
                                                case 'S':
                                                        fin=true;
                                                        break;
                                                default:
                                                        break;
                                        }
                                }
                        }catch(IOException ex){
                          error("Error leyendo del teclado o del Socket");
                        }
                }while(!fin);
        }

        public void apagar(){		//cierra los sockets
                try{
                        connect.close();
                }catch(IOException ex){
                  error("Error cerrando el Socket");
                }
        }

        public void error(String s){
                System.out.println(s);
                System.exit(1);		//sale de la aplicacion
        }
}