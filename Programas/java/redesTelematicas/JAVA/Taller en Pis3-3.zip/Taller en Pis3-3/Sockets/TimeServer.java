//import java.lang.System;
import java.net.DatagramPacket;	//formato de trama o paquete
import java.net.DatagramSocket;	//socket que me permite la conexion por UDP
import java.net.InetAddress;		
import java.io.IOException;
import java.util.Date;			//necesitamos el tiempo de la maquina local

public class TimeServer {
  public static void main(String args[]){
    try{
      DatagramSocket socket=new DatagramSocket(2345);	//creamos el socket
      String dirLocal=InetAddress.getLocalHost().getHostName().trim();	
      int puertoLocal=socket.getLocalPort();
      System.out.print(dirLocal+": ");
      System.out.println("Escuchando en Puerto: "+puertoLocal+".");
      int buffer=256;		//declaramos el buffer
      byte buffers[]=new byte[buffer];
      DatagramPacket datagrama=new DatagramPacket(buffers,buffer);
      boolean fin=false;
      do{
        socket.receive(datagrama);	//recibir paquetes de este tipo
        InetAddress dirDestino=datagrama.getAddress();	//toma la direccion 										//de donde viene
        String destino=dirDestino.getHostName().trim();
        int puertoDes=datagrama.getPort();
        System.out.println("\nDatagrama Recibido desde "+destino+" en el puerto "+puertoDes+".");
        String datos=new String(datagrama.getData(),0).trim(); //sacamos el dato
        System.out.println("Datos: "+datos);
        if(datos.equalsIgnoreCase("salir"))
          fin=true;
        String tiempo=new Date().toString();	//objeto del tipo date y lo 									//convertimos a cadena
        tiempo.getBytes(0,tiempo.length(),buffers,0);
//se arma el paquete
        datagrama=new DatagramPacket(buffers,buffer,dirDestino,puertoDes);
        socket.send(datagrama);		//enviamos el paquete
        System.out.println("Enviado: "+tiempo+" a "+destino+" en el puerto "+puertoDes+".");
      }while(!fin);
    }catch(IOException ex){
      System.out.println("Ocurri� una IOException");
    }
    }
}



